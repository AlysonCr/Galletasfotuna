import Galleta.Galleta;

import javax.swing.*;
import java.util.Scanner;

public class Main extends Galleta {
    public static void main(String[] args){

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {

                tufortuna Primer = new tufortuna();
                Primer.setVisible(true);
            }
        });


    }
}
