package Galleta;

public interface Frases {

    public Object frase();
}
