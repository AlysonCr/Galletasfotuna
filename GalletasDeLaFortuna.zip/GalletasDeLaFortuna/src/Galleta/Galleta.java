package Galleta;

public class Galleta implements Frases{

    public Galleta(){}

    @Override
    public Object frase() {
        String[] fras = {
                "Hoy sera el mejor día de tu vida",
                "No te apresures y tómalo con calma",
                "Piensa bien la decisión que tomarás",
                "Vendran cambios enormes para tu vida",
                "No te sientas triste, tendras otra oportunidad",
                "Te daran una noticia dolorosa",
                "Si ya te dijeron que no, no insistas más",

        };

        int val1 = (int) (Math.random() * 7);
        return fras[val1];

    }
}
