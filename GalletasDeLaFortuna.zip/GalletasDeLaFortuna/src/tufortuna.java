import Galleta.Galleta;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class tufortuna extends JFrame{

    private JButton Boton1;
    private JPanel VENTANA;

    public tufortuna(){
        add(VENTANA);

        setSize(500,500);
        setLocationRelativeTo(null);

        setDefaultCloseOperation(EXIT_ON_CLOSE);

        setTitle("Que te depara este día, " +
                "Descubre tu fortuna");

        Boton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Galleta cookie =new Galleta();
                String frase_muestra = (String) cookie.frase();
                JOptionPane.showMessageDialog(VENTANA, frase_muestra);

            }
        });
    }
}
